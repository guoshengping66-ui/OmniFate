"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[201,2582],{17740:(e,t,a)=>{a.d(t,{_:()=>n,e:()=>l});var r=a(95155),s=a(12115);let o=(0,s.createContext)({items:[],addItem:()=>{},removeItem:()=>{},updateQuantity:()=>{},clearCart:()=>{},itemCount:0,totalCny:0,totalWithDiscount:0,isMember:!1}),i="alpha_mirror_cart";function l({children:e,isMember:t=!1}){let[a,l]=(0,s.useState)([]);(0,s.useEffect)(()=>{try{let e=localStorage.getItem(i);e&&l(JSON.parse(e))}catch{}},[]),(0,s.useEffect)(()=>{localStorage.setItem(i,JSON.stringify(a))},[a]);let n=(0,s.useCallback)((e,t=1)=>{l(a=>a.find(t=>t.product.id===e.id)?a.map(a=>a.product.id===e.id?{...a,quantity:a.quantity+t}:a):[...a,{product:e,quantity:t}])},[]),d=(0,s.useCallback)(e=>{l(t=>t.filter(t=>t.product.id!==e))},[]),c=(0,s.useCallback)((e,t)=>{if(t<=0)return void l(t=>t.filter(t=>t.product.id!==e));l(a=>a.map(a=>a.product.id===e?{...a,quantity:t}:a))},[]),p=(0,s.useCallback)(()=>l([]),[]),u=a.reduce((e,t)=>e+t.quantity,0),m=a.reduce((e,t)=>e+t.product.price_cny*t.quantity,0),f=t?.88*m:m,g=(0,s.useMemo)(()=>({items:a,addItem:n,removeItem:d,updateQuantity:c,clearCart:p,itemCount:u,totalCny:m,totalWithDiscount:f,isMember:t}),[a,n,d,c,p,u,m,f,t]);return(0,r.jsx)(o.Provider,{value:g,children:e})}function n(){return(0,s.useContext)(o)}},39347:(e,t,a)=>{a.d(t,{A:()=>r});let r=(0,a(71847).A)("star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]])},44517:(e,t,a)=>{a.d(t,{Toaster:()=>K,Ay:()=>V});var r,s=a(12115);let o={data:""},i=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,n=/\n+/g,d=(e,t)=>{let a="",r="",s="";for(let o in e){let i=e[o];"@"==o[0]?"i"==o[1]?a=o+" "+i+";":r+="f"==o[1]?d(i,o):o+"{"+d(i,"k"==o[1]?"":t)+"}":"object"==typeof i?r+=d(i,t?t.replace(/([^,])+/g,e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=i&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=d.p?d.p(o,i):o+":"+i+";")}return a+(t&&s?t+"{"+s+"}":s)+r},c={},p=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+p(e[a]);return t}return e};function u(e){let t,a,r=this||{},s=e.call?e(r.p):e;return((e,t,a,r,s)=>{var o,u,m,f;let g=p(e),x=c[g]||(c[g]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(g));if(!c[x]){let t=g!==e?e:(e=>{let t,a,r=[{}];for(;t=i.exec(e.replace(l,""));)t[4]?r.shift():t[3]?(a=t[3].replace(n," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(n," ").trim();return r[0]})(e);c[x]=d(s?{["@keyframes "+x]:t}:t,a?"":"."+x)}let h=a&&c.g?c.g:null;return a&&(c.g=c[x]),o=c[x],u=t,m=r,(f=h)?u.data=u.data.replace(f,o):-1===u.data.indexOf(o)&&(u.data=m?o+u.data:u.data+o),x})(s.unshift?s.raw?(t=[].slice.call(arguments,1),a=r.p,s.reduce((e,r,s)=>{let o=t[s];if(o&&o.call){let e=o(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+r+(null==o?"":o)},"")):s.reduce((e,t)=>Object.assign(e,t&&t.call?t(r.p):t),{}):s,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||o})(r.target),r.g,r.o,r.k)}u.bind({g:1});let m,f,g,x=u.bind({k:1});function h(e,t){let a=this||{};return function(){let r=arguments;function s(o,i){let l=Object.assign({},o),n=l.className||s.className;a.p=Object.assign({theme:f&&f()},l),a.o=/ *go\d+/.test(n),l.className=u.apply(a,r)+(n?" "+n:""),t&&(l.ref=i);let d=e;return e[0]&&(d=l.as||e,delete l.as),g&&d[0]&&g(l),m(d,l)}return t?t(s):s}}var b=(e,t)=>"function"==typeof e?e(t):e,y=(()=>{let e=0;return()=>(++e).toString()})(),v=(()=>{let e;return()=>{if(void 0===e&&"u">typeof window){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),w="default",j=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return j(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+o}))}}},k=[],N={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},_={},C=(e,t=w)=>{_[t]=j(_[t]||N,e),k.forEach(([e,a])=>{e===t&&a(_[t])})},E=e=>Object.keys(_).forEach(t=>C(e,t)),$=(e=w)=>t=>{C(t,e)},z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},A=e=>(t,a)=>{let r,s=((e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||y()}))(t,e,a);return $(s.toasterId||(r=s.id,Object.keys(_).find(e=>_[e].toasts.some(e=>e.id===r))))({type:2,toast:s}),s.id},D=(e,t)=>A("blank")(e,t);D.error=A("error"),D.success=A("success"),D.loading=A("loading"),D.custom=A("custom"),D.dismiss=(e,t)=>{let a={type:3,toastId:e};t?$(t)(a):E(a)},D.dismissAll=e=>D.dismiss(void 0,e),D.remove=(e,t)=>{let a={type:4,toastId:e};t?$(t)(a):E(a)},D.removeAll=e=>D.remove(void 0,e),D.promise=(e,t,a)=>{let r=D.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?b(t.success,e):void 0;return s?D.success(s,{id:r,...a,...null==a?void 0:a.success}):D.dismiss(r),e}).catch(e=>{let s=t.error?b(t.error,e):void 0;s?D.error(s,{id:r,...a,...null==a?void 0:a.error}):D.dismiss(r)}),e};var O=1e3,I=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,S=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,M=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,P=h("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${I} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${S} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${M} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,T=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,F=h("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${T} 1s linear infinite;
`,L=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,q=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,H=h("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${L} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${q} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,R=h("div")`
  position: absolute;
`,W=h("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,J=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,U=h("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${J} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,X=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?s.createElement(U,null,t):t:"blank"===a?null:s.createElement(W,null,s.createElement(F,{...r}),"loading"!==a&&s.createElement(R,null,"error"===a?s.createElement(P,{...r}):s.createElement(H,{...r})))},B=h("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Q=h("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Y=s.memo(({toast:e,position:t,style:a,children:r})=>{let o=e.height?((e,t)=>{let a=e.includes("top")?1:-1,[r,s]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*a}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*a}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${x(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},i=s.createElement(X,{toast:e}),l=s.createElement(Q,{...e.ariaProps},b(e.message,e));return s.createElement(B,{className:e.className,style:{...o,...a,...e.style}},"function"==typeof r?r({icon:i,message:l}):s.createElement(s.Fragment,null,i,l))});r=s.createElement,d.p=void 0,m=r,f=void 0,g=void 0;var Z=({id:e,className:t,style:a,onHeightUpdate:r,children:o})=>{let i=s.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return s.createElement("div",{ref:i,className:t,style:a},o)},G=u`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,K=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:o,toasterId:i,containerStyle:l,containerClassName:n})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:a,pausedAt:r}=((e={},t=w)=>{let[a,r]=(0,s.useState)(_[t]||N),o=(0,s.useRef)(_[t]);(0,s.useEffect)(()=>(o.current!==_[t]&&r(_[t]),k.push([t,r]),()=>{let e=k.findIndex(([e])=>e===t);e>-1&&k.splice(e,1)}),[t]);let i=a.toasts.map(t=>{var a,r,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||z[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...a,toasts:i}})(e,t),o=(0,s.useRef)(new Map).current,i=(0,s.useCallback)((e,t=O)=>{if(o.has(e))return;let a=setTimeout(()=>{o.delete(e),l({type:4,toastId:e})},t);o.set(e,a)},[]);(0,s.useEffect)(()=>{if(r)return;let e=Date.now(),s=a.map(a=>{if(a.duration===1/0)return;let r=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(r<0){a.visible&&D.dismiss(a.id);return}return setTimeout(()=>D.dismiss(a.id,t),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[a,r,t]);let l=(0,s.useCallback)($(t),[t]),n=(0,s.useCallback)(()=>{l({type:5,time:Date.now()})},[l]),d=(0,s.useCallback)((e,t)=>{l({type:1,toast:{id:e,height:t}})},[l]),c=(0,s.useCallback)(()=>{r&&l({type:6,time:Date.now()})},[r,l]),p=(0,s.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:o}=t||{},i=a.filter(t=>(t.position||o)===(e.position||o)&&t.height),l=i.findIndex(t=>t.id===e.id),n=i.filter((e,t)=>t<l&&e.visible).length;return i.filter(e=>e.visible).slice(...r?[n+1]:[0,n]).reduce((e,t)=>e+(t.height||0)+s,0)},[a]);return(0,s.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=o.get(e.id);t&&(clearTimeout(t),o.delete(e.id))}})},[a,i]),{toasts:a,handlers:{updateHeight:d,startPause:n,endPause:c,calculateOffset:p}}})(a,i);return s.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...l},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(a=>{let i=a.position||t,l=((e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}})(i,c.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return s.createElement(Z,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?G:"",style:l},"custom"===a.type?b(a.message,a):o?o(a):s.createElement(Y,{toast:a,position:i}))}))},V=D},60201:(e,t,a)=>{a.r(t),a.d(t,{ProductCard:()=>g});var r=a(95155),s=a(12115),o=a(95740),i=a(39347),l=a(5917),n=a(10512),d=a(52619),c=a.n(d),p=a(17740),u=a(30232),m=a(99040),f=a(44517);function g({product:e}){var t,a;let{addItem:d}=(0,p._)(),{t:g}=(0,u.o)(),[x,h]=(0,s.useState)(!1),b=null!=e.match_score&&e.match_score>0,y=null==(t=e.match_score)?"border-gold/20":t>=10?"border-gold border-2 shadow-[0_0_30px_rgba(201,168,76,0.4)]":t>=7?"border-gold/70 shadow-[0_0_20px_rgba(201,168,76,0.25)]":t>=4?"border-gold/40 shadow-[0_0_10px_rgba(201,168,76,0.12)]":"border-gold/20",v=null==(a=e.match_score)?"opacity-0":a>=10?"opacity-70":a>=7?"opacity-40":a>=4?"opacity-20":"opacity-0";return(0,r.jsxs)(c(),{href:`/shop/${e.id}`,className:`block relative card-glow p-5 flex gap-4 overflow-hidden ${y} hover:border-gold/40 transition-all duration-300`,children:[b&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("div",{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{background:`conic-gradient(from var(--angle, 0deg),
                transparent 0%,
                rgba(201,168,76,${v}) 25%,
                transparent 50%,
                rgba(201,168,76,${v}) 75%,
                transparent 100%
              )`,animation:"glow-rotate 4s linear infinite",WebkitMask:"linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",WebkitMaskComposite:"xor",maskComposite:"exclude",padding:"2px"}}),(0,r.jsx)("div",{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{background:`radial-gradient(ellipse at center, rgba(201,168,76,${v}) 0%, transparent 70%)`,opacity:.3,animation:"pulse-glow 3s ease-in-out infinite"}})]}),(0,r.jsx)(m.X,{src:e.image_url,alt:e.name,category:e.category,size:"md",className:"flex-shrink-0"}),(0,r.jsxs)("div",{className:"flex-1 min-w-0 relative z-10",children:[(0,r.jsxs)("div",{className:"flex items-start justify-between gap-2 mb-1",children:[(0,r.jsx)("h3",{className:"font-medium text-white text-sm leading-tight",children:e.name}),(0,r.jsxs)("div",{className:"flex items-center gap-1.5 flex-shrink-0",children:[b&&(0,r.jsxs)("span",{className:"flex items-center gap-0.5 text-xs text-gold/80",children:[(0,r.jsx)(o.A,{size:10,className:"fill-gold/30"}),e.match_score?.toFixed(1)]}),e.rating&&(0,r.jsxs)("div",{className:"flex items-center gap-0.5",children:[(0,r.jsx)(i.A,{size:11,className:"text-gold fill-gold"}),(0,r.jsx)("span",{className:"text-xs text-gold",children:e.rating})]})]})]}),e.short_pitch&&(0,r.jsx)("p",{className:"text-white/50 text-xs leading-relaxed line-clamp-2 mb-2",children:e.short_pitch}),e.recommendation_text&&(0,r.jsxs)("p",{className:"text-gold/70 text-xs leading-relaxed italic mb-2 border-l-2 border-gold/30 pl-2",children:["“",e.recommendation_text,"”"]}),e.match_reasons&&e.match_reasons.length>0&&(0,r.jsx)("div",{className:"flex gap-1 flex-wrap mb-2",children:e.match_reasons.slice(0,2).map(e=>(0,r.jsx)("span",{className:"text-xs px-1.5 py-0.5 bg-gold/10 text-gold/70 rounded-full",children:e},e))}),!b&&e.keyword_tags&&(0,r.jsx)("div",{className:"flex gap-1 flex-wrap mb-3",children:e.keyword_tags.slice(0,3).map(e=>(0,r.jsx)("span",{className:"text-xs px-1.5 py-0.5 bg-gold/10 text-gold/70 rounded-full",children:e},e))}),(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsxs)("span",{className:"text-gold font-bold",children:["\xa5",e.price_cny.toFixed(0)]}),(0,r.jsxs)("button",{onClick:t=>{t.preventDefault(),t.stopPropagation(),d(e),h(!0),f.Ay.success(g("shop.addedToCart").replace("{name}",e.name)),setTimeout(()=>h(!1),1500)},className:`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full transition-all
              ${x?"bg-green-500/20 border border-green-500/40 text-green-400":"bg-gold/10 border border-gold/30 text-gold hover:bg-gold/20"}`,children:[x?(0,r.jsx)(l.A,{size:12}):(0,r.jsx)(n.A,{size:12}),x?g("shop.added"):g("shop.addToCart")]})]})]})]})}},99040:(e,t,a)=>{a.d(t,{X:()=>d});var r=a(95155),s=a(12115),o=a(15239);let i={crystal:{emoji:"\uD83D\uDC8E",gradient:"from-purple-500/20 to-purple-600/5"},jewelry:{emoji:"\uD83D\uDC8D",gradient:"from-amber-500/20 to-amber-600/5"},incense:{emoji:"\uD83D\uDD6F️",gradient:"from-orange-500/20 to-orange-600/5"},talisman:{emoji:"\uD83D\uDCDC",gradient:"from-red-500/20 to-red-600/5"},book:{emoji:"\uD83D\uDCD6",gradient:"from-blue-500/20 to-blue-600/5"},service:{emoji:"✨",gradient:"from-gold/20 to-gold/5"},other:{emoji:"\uD83D\uDD2E",gradient:"from-violet-500/20 to-violet-600/5"}},l={emoji:"\uD83D\uDD2E",gradient:"from-violet-500/20 to-violet-600/5"},n={sm:"w-16 h-16 text-2xl",md:"w-20 h-20 text-3xl",lg:"w-64 h-64 text-7xl"};function d({src:e,alt:t,category:a,className:d="",size:c="md"}){let[p,u]=(0,s.useState)(!1),[m,f]=(0,s.useState)(!0),g=i[a||""]||l,x=e&&!p;return(0,r.jsx)("div",{className:`relative flex items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br ${g.gradient} border border-white/10 ${n[c]} ${d}`,children:x?(0,r.jsxs)(r.Fragment,{children:[m&&(0,r.jsx)("div",{className:"absolute inset-0 flex items-center justify-center",children:(0,r.jsx)("div",{className:"w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full animate-spin"})}),(0,r.jsx)(o.default,{src:e,alt:t,fill:!0,className:`object-cover transition-opacity duration-300 ${m?"opacity-0":"opacity-100"}`,sizes:"(max-width: 768px) 80px, 256px",unoptimized:!0,onLoad:()=>f(!1),onError:()=>u(!0)})]}):(0,r.jsx)("span",{className:"select-none",children:g.emoji})})}}}]);