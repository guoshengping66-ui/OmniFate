"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4364],{17740:(e,t,a)=>{a.d(t,{_:()=>l,e:()=>n});var r=a(95155),s=a(12115);let i=(0,s.createContext)({items:[],addItem:()=>{},removeItem:()=>{},updateQuantity:()=>{},clearCart:()=>{},itemCount:0,totalCny:0,totalWithDiscount:0,isMember:!1}),o="alpha_mirror_cart";function n({children:e,isMember:t=!1}){let[a,n]=(0,s.useState)([]);(0,s.useEffect)(()=>{try{let e=localStorage.getItem(o);e&&n(JSON.parse(e))}catch{}},[]),(0,s.useEffect)(()=>{localStorage.setItem(o,JSON.stringify(a))},[a]);let l=(0,s.useCallback)((e,t=1)=>{n(a=>a.find(t=>t.product.id===e.id)?a.map(a=>a.product.id===e.id?{...a,quantity:a.quantity+t}:a):[...a,{product:e,quantity:t}])},[]),d=(0,s.useCallback)(e=>{n(t=>t.filter(t=>t.product.id!==e))},[]),c=(0,s.useCallback)((e,t)=>{if(t<=0)return void n(t=>t.filter(t=>t.product.id!==e));n(a=>a.map(a=>a.product.id===e?{...a,quantity:t}:a))},[]),u=(0,s.useCallback)(()=>n([]),[]),m=a.reduce((e,t)=>e+t.quantity,0),p=a.reduce((e,t)=>e+t.product.price_cny*t.quantity,0),f=t?.88*p:p,g=(0,s.useMemo)(()=>({items:a,addItem:l,removeItem:d,updateQuantity:c,clearCart:u,itemCount:m,totalCny:p,totalWithDiscount:f,isMember:t}),[a,l,d,c,u,m,p,f,t]);return(0,r.jsx)(i.Provider,{value:g,children:e})}function l(){return(0,s.useContext)(i)}},44517:(e,t,a)=>{a.d(t,{Toaster:()=>K,Ay:()=>V});var r,s=a(12115);let i={data:""},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,d=(e,t)=>{let a="",r="",s="";for(let i in e){let o=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+o+";":r+="f"==i[1]?d(o,i):i+"{"+d(o,"k"==i[1]?"":t)+"}":"object"==typeof o?r+=d(o,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=o&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=d.p?d.p(i,o):i+":"+o+";")}return a+(t&&s?t+"{"+s+"}":s)+r},c={},u=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+u(e[a]);return t}return e};function m(e){let t,a,r=this||{},s=e.call?e(r.p):e;return((e,t,a,r,s)=>{var i,m,p,f;let g=u(e),x=c[g]||(c[g]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(g));if(!c[x]){let t=g!==e?e:(e=>{let t,a,r=[{}];for(;t=o.exec(e.replace(n,""));)t[4]?r.shift():t[3]?(a=t[3].replace(l," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(l," ").trim();return r[0]})(e);c[x]=d(s?{["@keyframes "+x]:t}:t,a?"":"."+x)}let h=a&&c.g?c.g:null;return a&&(c.g=c[x]),i=c[x],m=t,p=r,(f=h)?m.data=m.data.replace(f,i):-1===m.data.indexOf(i)&&(m.data=p?i+m.data:m.data+i),x})(s.unshift?s.raw?(t=[].slice.call(arguments,1),a=r.p,s.reduce((e,r,s)=>{let i=t[s];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"")):s.reduce((e,t)=>Object.assign(e,t&&t.call?t(r.p):t),{}):s,(e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i})(r.target),r.g,r.o,r.k)}m.bind({g:1});let p,f,g,x=m.bind({k:1});function h(e,t){let a=this||{};return function(){let r=arguments;function s(i,o){let n=Object.assign({},i),l=n.className||s.className;a.p=Object.assign({theme:f&&f()},n),a.o=/ *go\d+/.test(l),n.className=m.apply(a,r)+(l?" "+l:""),t&&(n.ref=o);let d=e;return e[0]&&(d=n.as||e,delete n.as),g&&d[0]&&g(n),p(d,n)}return t?t(s):s}}var b=(e,t)=>"function"==typeof e?e(t):e,y=(()=>{let e=0;return()=>(++e).toString()})(),v=(()=>{let e;return()=>{if(void 0===e&&"u">typeof window){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),j="default",w=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return w(e,{type:+!!e.toasts.find(e=>e.id===r.id),toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},N=[],k={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},C={},$=(e,t=j)=>{C[t]=w(C[t]||k,e),N.forEach(([e,a])=>{e===t&&a(C[t])})},E=e=>Object.keys(C).forEach(t=>$(e,t)),_=(e=j)=>t=>{$(t,e)},A={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},z=e=>(t,a)=>{let r,s=((e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||y()}))(t,e,a);return _(s.toasterId||(r=s.id,Object.keys(C).find(e=>C[e].toasts.some(e=>e.id===r))))({type:2,toast:s}),s.id},I=(e,t)=>z("blank")(e,t);I.error=z("error"),I.success=z("success"),I.loading=z("loading"),I.custom=z("custom"),I.dismiss=(e,t)=>{let a={type:3,toastId:e};t?_(t)(a):E(a)},I.dismissAll=e=>I.dismiss(void 0,e),I.remove=(e,t)=>{let a={type:4,toastId:e};t?_(t)(a):E(a)},I.removeAll=e=>I.remove(void 0,e),I.promise=(e,t,a)=>{let r=I.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?b(t.success,e):void 0;return s?I.success(s,{id:r,...a,...null==a?void 0:a.success}):I.dismiss(r),e}).catch(e=>{let s=t.error?b(t.error,e):void 0;s?I.error(s,{id:r,...a,...null==a?void 0:a.error}):I.dismiss(r)}),e};var D=1e3,O=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,S=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,F=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,M=h("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${O} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${S} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,T=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,P=h("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${T} 1s linear infinite;
`,L=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,q=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,H=h("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${L} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${q} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,R=h("div")`
  position: absolute;
`,B=h("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,J=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,U=h("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${J} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,W=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?s.createElement(U,null,t):t:"blank"===a?null:s.createElement(B,null,s.createElement(P,{...r}),"loading"!==a&&s.createElement(R,null,"error"===a?s.createElement(M,{...r}):s.createElement(H,{...r})))},X=h("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Q=h("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Y=s.memo(({toast:e,position:t,style:a,children:r})=>{let i=e.height?((e,t)=>{let a=e.includes("top")?1:-1,[r,s]=v()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*a}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*a}%,-1px) scale(.6); opacity:0;}
`];return{animation:t?`${x(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},o=s.createElement(W,{toast:e}),n=s.createElement(Q,{...e.ariaProps},b(e.message,e));return s.createElement(X,{className:e.className,style:{...i,...a,...e.style}},"function"==typeof r?r({icon:o,message:n}):s.createElement(s.Fragment,null,o,n))});r=s.createElement,d.p=void 0,p=r,f=void 0,g=void 0;var Z=({id:e,className:t,style:a,onHeightUpdate:r,children:i})=>{let o=s.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return s.createElement("div",{ref:o,className:t,style:a},i)},G=m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,K=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:i,toasterId:o,containerStyle:n,containerClassName:l})=>{let{toasts:d,handlers:c}=((e,t="default")=>{let{toasts:a,pausedAt:r}=((e={},t=j)=>{let[a,r]=(0,s.useState)(C[t]||k),i=(0,s.useRef)(C[t]);(0,s.useEffect)(()=>(i.current!==C[t]&&r(C[t]),N.push([t,r]),()=>{let e=N.findIndex(([e])=>e===t);e>-1&&N.splice(e,1)}),[t]);let o=a.toasts.map(t=>{var a,r,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||A[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...a,toasts:o}})(e,t),i=(0,s.useRef)(new Map).current,o=(0,s.useCallback)((e,t=D)=>{if(i.has(e))return;let a=setTimeout(()=>{i.delete(e),n({type:4,toastId:e})},t);i.set(e,a)},[]);(0,s.useEffect)(()=>{if(r)return;let e=Date.now(),s=a.map(a=>{if(a.duration===1/0)return;let r=(a.duration||0)+a.pauseDuration-(e-a.createdAt);if(r<0){a.visible&&I.dismiss(a.id);return}return setTimeout(()=>I.dismiss(a.id,t),r)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[a,r,t]);let n=(0,s.useCallback)(_(t),[t]),l=(0,s.useCallback)(()=>{n({type:5,time:Date.now()})},[n]),d=(0,s.useCallback)((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),c=(0,s.useCallback)(()=>{r&&n({type:6,time:Date.now()})},[r,n]),u=(0,s.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:i}=t||{},o=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<n&&e.visible).length;return o.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[a]);return(0,s.useEffect)(()=>{a.forEach(e=>{if(e.dismissed)o(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[a,o]),{toasts:a,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}})(a,o);return s.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(a=>{let o=a.position||t,n=((e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:v()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}})(o,c.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return s.createElement(Z,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?G:"",style:n},"custom"===a.type?b(a.message,a):i?i(a):s.createElement(Y,{toast:a,position:o}))}))},V=I},56154:(e,t,a)=>{a.d(t,{A:()=>r});let r=(0,a(71847).A)("zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]])},64364:(e,t,a)=>{a.r(t),a.d(t,{AIRecommendHero:()=>f});var r=a(95155),s=a(12115),i=a(56154),o=a(95740),n=a(5917),l=a(10512),d=a(17740),c=a(30232),u=a(99040),m=a(44517);let p=["#C9A84C","#A78BFA","#60A5FA"];function f({products:e}){let{addItem:t}=(0,d._)(),{t:a}=(0,c.o)(),[f,g]=(0,s.useState)(!1),[x,h]=(0,s.useState)(new Set),b=[a("shop.ai.bestMatch"),a("shop.ai.strongRec"),a("shop.ai.worthIt")],y=e.slice(0,3);return((0,s.useEffect)(()=>{let e=setTimeout(()=>g(!0),400);return()=>clearTimeout(e)},[]),0===y.length)?null:(0,r.jsxs)("div",{className:"mb-12",children:[(0,r.jsxs)("div",{className:"flex items-center gap-3 mb-6 anim-slide-up",children:[(0,r.jsxs)("div",{className:"flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold/10 border border-gold/25",children:[(0,r.jsx)(i.A,{size:14,className:"text-gold"}),(0,r.jsx)("span",{className:"text-gold text-xs font-semibold tracking-wide",children:a("shop.ai.selected")})]}),(0,r.jsx)("div",{className:"flex-1 h-px bg-gradient-to-r from-gold/20 to-transparent"})]}),(0,r.jsx)("div",{className:"grid md:grid-cols-3 gap-5",children:y.map((e,s)=>(0,r.jsx)("div",{className:f?"anim-slide-up":"opacity-0",style:f?{animationDelay:`${.15*s}s`}:void 0,children:(0,r.jsxs)("div",{className:"relative group rounded-2xl overflow-hidden border border-white/10 hover:border-gold/40 transition-all duration-500",children:[(0,r.jsx)("div",{className:"absolute inset-0 rounded-2xl pointer-events-none",style:{padding:"1.5px",background:`conic-gradient(from var(--angle,0deg), transparent 0%, ${p[s]}66 50%, transparent 100%)`,mask:"linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",maskComposite:"exclude",WebkitMaskComposite:"xor",animation:"glow-rotate 5s linear infinite"}}),(0,r.jsx)("div",{className:"absolute inset-0 rounded-2xl pointer-events-none opacity-30 group-hover:opacity-50 transition-opacity",style:{background:`radial-gradient(ellipse at 50% 0%, ${p[s]}20, transparent 70%)`}}),(0,r.jsxs)("div",{className:"relative bg-gradient-to-b from-[#1a1430]/95 to-[#140f24]/95 backdrop-blur-xl p-5",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,r.jsxs)("div",{className:"flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold",style:{background:`${p[s]}15`,border:`1px solid ${p[s]}40`,color:p[s]},children:[(0,r.jsxs)("span",{className:"text-sm",children:["#",s+1]}),b[s]]}),null!=e.match_score&&(0,r.jsxs)("div",{className:"flex items-center gap-1 text-xs text-gold/70",children:[(0,r.jsx)(o.A,{size:10,className:"fill-gold/30"}),e.match_score.toFixed(1)]})]}),(0,r.jsxs)("div",{className:"flex items-start gap-3 mb-4",children:[(0,r.jsx)(u.X,{src:e.image_url,alt:e.name,category:e.category,size:"sm",className:"flex-shrink-0"}),(0,r.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,r.jsx)("h3",{className:"font-serif font-bold text-white text-base mb-1 truncate",children:e.name}),(0,r.jsxs)("p",{className:"text-gold font-bold text-lg",children:["\xa5",e.price_cny.toFixed(0)]})]})]}),e.recommendation_text&&(0,r.jsxs)("p",{className:"text-white/40 text-xs leading-relaxed mb-3 line-clamp-2 italic border-l-2 border-gold/20 pl-2",children:["“",e.recommendation_text,"”"]}),e.match_reasons&&e.match_reasons.length>0&&(0,r.jsx)("div",{className:"flex gap-1 flex-wrap mb-4",children:e.match_reasons.slice(0,3).map(e=>(0,r.jsx)("span",{className:"text-[10px] px-1.5 py-0.5 rounded-full",style:{background:`${p[s]}10`,color:`${p[s]}cc`,border:`1px solid ${p[s]}20`},children:e},e))}),(0,r.jsx)("button",{onClick:()=>{t(e),h(t=>new Set(t).add(e.id)),m.Ay.success(a("shop.addedToCart").replace("{name}",e.name))},disabled:x.has(e.id),className:`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${x.has(e.id)?"bg-green-500/15 border border-green-500/30 text-green-400":"bg-gold/10 border border-gold/30 text-gold hover:bg-gold/20 hover:shadow-[0_0_20px_rgba(201,168,76,0.15)]"}`,children:x.has(e.id)?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(n.A,{size:14})," ",a("shop.added")]}):(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(l.A,{size:14})," ",a("shop.ai.addToCart2")]})})]})]})},e.id))})]})}},99040:(e,t,a)=>{a.d(t,{X:()=>d});var r=a(95155),s=a(12115),i=a(15239);let o={crystal:{emoji:"\uD83D\uDC8E",gradient:"from-purple-500/20 to-purple-600/5"},jewelry:{emoji:"\uD83D\uDC8D",gradient:"from-amber-500/20 to-amber-600/5"},incense:{emoji:"\uD83D\uDD6F️",gradient:"from-orange-500/20 to-orange-600/5"},talisman:{emoji:"\uD83D\uDCDC",gradient:"from-red-500/20 to-red-600/5"},book:{emoji:"\uD83D\uDCD6",gradient:"from-blue-500/20 to-blue-600/5"},service:{emoji:"✨",gradient:"from-gold/20 to-gold/5"},other:{emoji:"\uD83D\uDD2E",gradient:"from-violet-500/20 to-violet-600/5"}},n={emoji:"\uD83D\uDD2E",gradient:"from-violet-500/20 to-violet-600/5"},l={sm:"w-16 h-16 text-2xl",md:"w-20 h-20 text-3xl",lg:"w-64 h-64 text-7xl"};function d({src:e,alt:t,category:a,className:d="",size:c="md"}){let[u,m]=(0,s.useState)(!1),[p,f]=(0,s.useState)(!0),g=o[a||""]||n,x=e&&!u;return(0,r.jsx)("div",{className:`relative flex items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br ${g.gradient} border border-white/10 ${l[c]} ${d}`,children:x?(0,r.jsxs)(r.Fragment,{children:[p&&(0,r.jsx)("div",{className:"absolute inset-0 flex items-center justify-center",children:(0,r.jsx)("div",{className:"w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full animate-spin"})}),(0,r.jsx)(i.default,{src:e,alt:t,fill:!0,className:`object-cover transition-opacity duration-300 ${p?"opacity-0":"opacity-100"}`,sizes:"(max-width: 768px) 80px, 256px",unoptimized:!0,onLoad:()=>f(!1),onError:()=>m(!0)})]}):(0,r.jsx)("span",{className:"select-none",children:g.emoji})})}}}]);