"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3918],{3918:(e,t,a)=>{a.r(t),a.d(t,{StarField:()=>o});var n=a(95155),r=a(12115);function o(){let e=(0,r.useRef)(null),t=(0,r.useRef)([]),a=(0,r.useRef)([]),o=(0,r.useCallback)(()=>{if(!e.current)return;let t=document.createElement("div"),n=Math.random()*window.innerWidth,r=Math.random()*(.5*window.innerHeight),o=30+30*Math.random(),i=200+300*Math.random();t.className="shooting-star",t.style.cssText=`
      position: fixed;
      left: ${n}px;
      top: ${r}px;
      width: 100px;
      height: 1px;
      background: linear-gradient(90deg, transparent, #C9A84C, transparent);
      transform: rotate(${o}deg);
      opacity: 0;
      pointer-events: none;
      z-index: 1;
    `,document.body.appendChild(t),a.current.push(t),t.animate([{opacity:0,transform:`rotate(${o}deg) translateX(0)`},{opacity:.8,transform:`rotate(${o}deg) translateX(${.3*i}px)`,offset:.2},{opacity:0,transform:`rotate(${o}deg) translateX(${i}px)`}],{duration:1500+1e3*Math.random(),easing:"ease-out"}).onfinish=()=>{t.remove(),a.current=a.current.filter(e=>e!==t)}},[]);return(0,r.useEffect)(()=>{if(!e.current)return;let n=e.current,r=()=>{for(let e=0;e<60;e++){let e=document.createElement("div"),a=2.5*Math.random()+.5,r=100*Math.random(),o=100*Math.random();e.className="star",e.style.cssText=`
          width:${a}px; height:${a}px;
          left:${r}%; top:${o}%;
          --dur:${(4*Math.random()+2).toFixed(1)}s;
          animation-delay:${(5*Math.random()).toFixed(1)}s;
          opacity:${.6*Math.random()+.1};
        `,n.appendChild(e),t.current.push({x:r,y:o,size:a,element:e})}let e=t.current.filter(e=>e.size>1.5);for(let t=0;t<Math.min(4,e.length-1);t++){let a=e[t],r=e[t+1],o=document.createElement("div");o.className="constellation-line";let i=r.x-a.x,s=r.y-a.y,l=Math.sqrt(i*i+s*s),d=180/Math.PI*Math.atan2(s,i);o.style.cssText=`
          position: absolute;
          left: ${a.x}%;
          top: ${a.y}%;
          width: ${l}%;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(201,168,76,0.3), transparent);
          transform-origin: 0 0;
          transform: rotate(${d}deg);
          opacity: 0;
          animation: constellation-fade 8s ease-in-out infinite;
          animation-delay: ${1.5*t}s;
        `,n.appendChild(o)}},i="undefined"!=typeof requestIdleCallback?requestIdleCallback(r,{timeout:2e3}):setTimeout(r,500),s=setInterval(()=>{Math.random()>.7&&o()},5e3);return()=>{"undefined"!=typeof cancelIdleCallback?cancelIdleCallback(i):clearTimeout(i),clearInterval(s),a.current.forEach(e=>e.remove())}},[o]),(0,n.jsx)("div",{ref:e,className:"stars","aria-hidden":!0})}}}]);